# Fernhill PR house rules

Version 0.9 · 5 November 2026 · Built by Encoded from 3 published pieces and your questionnaire answers.

> **Example kit.** Fernhill PR and everything in it is fictional, made to show what a House Rules Kit looks like.

> How to use this: these are the rules your AI follows when it drafts, and the rules the checker tests. **Must** rules block a draft until fixed. **Should** rules improve it. "Your answer" means the rule came straight from you; "measured" means we counted it in your published work; "observed break" means it went wrong in the AI draft you sent us. Rules marked "Please confirm" are ones we want you to check.

## At a glance

- **Formats covered:** expert comment listicles (priority), press releases (from your answers only, see section 2)
- **English:** UK
- **Rules:** 23 Must · 9 Should
- **Version 0.9** because we built from 3 samples. Send 2 more expert pieces, or choose the Calibrated Kit, to reach 1.0.
- Rules marked **Expert listicles only** do not apply to press releases. Every other rule applies to everything.

## 1. Voice

Fernhill writes like a calm, practical friend who happens to be an expert. Each point names a real problem in plain words, says why it matters in one sentence, then gives one thing to do about it. Consequences are stated honestly but never dramatised, and the expert's closing quote leaves the reader feeling capable, not scared.

**Sounds like:** clear, practical, warm, specific, reassuring
**Never sounds like:** salesy, alarmist, breathless, jokey, preachy

From your own work:
> "Claims only backdate three months, so a late claim loses money for good." (Ledgerwise)
> "Press your thumb into the midsole. If it feels firm and flat, it is time for a new pair." (Stridewell)
> "A good sponge is mostly patience," Price says. "Weigh, wait and leave the oven shut." (Kettle & Crumb)

**V1 (Must)** Open on the point.
Pass if: the first sentence after the headline states the problem or finding readers care about. No scene-setting, no "In today's..." openers.
✅ "Most new parents budget for nappies and a pram. Far fewer plan for the costs and paperwork that arrive in the first year."
❌ "In today's fast-paced world, becoming a parent is a thrilling journey"
Source: measured 3/3; observed break; Encoded default.

**V2 (Should)** Describe risks plainly, with a fix, and without scare words.
Pass if: every risk is followed by an action; no words like "nightmare", "terrifying" or "devastating" ("disaster" is banned outright in N1).
Source: your answer (Q3.8: "never scary").

**V3 (Should)** Expert listicles only. Speak to the reader as "you" in the advice lines.
Pass if: "What to do:" lines address the reader directly.
✅ "Book a will appointment before your baby is six months old."
Source: measured 3/3.

**V4 (Should)** Write "it is" and "do not" in full outside quotes.
Pass if: no contractions in the body text; contractions inside quotes are fine.
Source: measured 3/3. Please confirm this is deliberate.

## 2. Structure and format

### Expert comment listicles (priority)

**Shape:**
1. Headline
2. One or two sentence standfirst that opens on the point
3. Expert intro line: "Full Name, credential at Company, says:"
4. Numbered items. Each item: a short subhead, then "Why it matters:", then "What to do:"
5. Closing quote from the expert, in two parts

**Length:** 225 to 262 words across your 3 samples (headline included, item numbers not counted).

**S1 (Must)** Expert listicles only. Follow the shape above, in that order.
Pass if: all five parts are present and in order.
Source: measured 3/3.

**S2 (Must)** Expert listicles only. The number in the headline equals the number of items.
Pass if: count the headline number, count the numbered items; they match. When cutting, merge two items; never leave the count wrong.
✅ "5 money mistakes new parents make..." with 5 items
❌ "6 Financial Mistakes Every New Parent Makes" with 7 items
Source: your answer (Q4.1, top fix); measured 3/3; observed break.

**S3 (Must)** Expert listicles only. Every item has exactly two labels, "Why it matters:" then "What to do:", word for word.
Pass if: both labels in every item, in that order, with the same capitals and colons.
Source: your answer (Q3.2: "Exactly like that."); measured 3/3.

**S4 (Must)** No other labels, in any format.
Pass if: no "Tip:", "Top tip:", "Key takeaway:", "Script to use:" or any other added label.
❌ "1. Not having a will. Tip: Get one written ASAP."
Source: your answer (Q3.5, Q4.1); observed break.

**S5 (Must)** Expert listicles only. Items are the thing the headline promises.
Pass if: "mistakes" are things people get wrong, "signs" are things you can notice; no item turns into a general tip.
Source: Encoded default; consistent with 3/3 samples.

**S6 (Should)** Expert listicles only. Keep item subheads short and concrete.
Pass if: 3 to 7 words, naming the mistake or sign itself ("Claiming Child Benefit late").
Source: measured 3/3 (range 3 to 7 words).

**S7 (Should)** Expert listicles only. "Why it matters:" is one sentence. "What to do:" is one or two sentences with a concrete action.
Pass if: sentence counts match; the action is something a reader could do this week.
Source: measured 3/3.

**S8 (Must)** Expert listicles only. End with a two-part quote from the expert.
Pass if: the piece ends: "First sentence," Surname says. "Second sentence."
✅ "Your shoes do a lot of quiet work," Reyes says. "Replacing them on time is cheaper than a course of physio."
Source: measured 3/3.

**S9 (Should)** Expert listicles only. Keep to 225 to 262 words.
Pass if: word count (headline included, item numbers not counted) is between 225 and 262.
Source: measured 3/3. You told us 250 to 350, but your published pieces are shorter, so we used them. Please confirm.

**S10 (Must)** Expert listicles only. Every point in the brief gets its own item.
Pass if: each point in the journalist request or client brief maps to one item; none merged away, none missing.
Source: Encoded default.

**S11 (Must)** Expert listicles only. Keep the headline's angle all the way through.
Pass if: a cautionary headline ("mistakes") gets a cautionary body; a diagnostic headline ("signs") diagnoses rather than prescribes.
Source: Encoded default.

### Press releases

We had no press release among your samples, so these come from your answers only. Send one or two published releases and we will add the full structure.

**P1 (Should)** Press releases run 400 to 500 words.
Pass if: word count is between 400 and 500.
Source: your answer (Q2.5). Please confirm.

## 3. Headlines

**H1 (Must)** Expert listicles only. Start with the number, as a digit.
Pass if: the first character is a digit.
Source: your answer (Q3.1); measured 3/3.

**H2 (Must)** Expert listicles only. Name the expert's real credential. Never "expert".
Pass if: the headline names a credential (usually "according to a [credential]") and does not contain "expert".
✅ "5 money mistakes new parents make, according to a chartered financial planner"
❌ "6 Financial Mistakes Every New Parent Makes" (no credential at all)
Source: your answer (Q3.1, Q4.1); measured 3/3; observed break.

**H3 (Must)** Sentence case, in every format.
Pass if: only the first word and proper nouns are capitalised.
❌ "6 Financial Mistakes Every New Parent Makes"
Source: your answer (Q3.7); measured 3/3; observed break.

**H4 (Should)** Expert listicles only. Keep headlines to 12 or 13 words.
Pass if: the headline is 12 or 13 words.
Source: measured 3/3.

## 4. Language and spelling

**L1 (Must)** UK spelling and terms throughout.
Pass if: no US spellings (color, organize, center) or terms (diapers, sneakers, vacation).
❌ "Start a color-coded budget."
Source: your answer (Q2.4, Q4.1); measured 3/3; observed break.

**L2 (Must)** Money in pounds, written like £2.5m.
Pass if: no $ or other currencies unless the brief is about them; millions as "m".
❌ "$1,200 a month"
Source: your answer (Q3.4); observed break.

**L3 (Must)** One to nine in words, 10 and above in digits. The headline number is always a digit.
Pass if: "three months", "six months"; "20 minutes", "500 miles", "2,000 UK adults". Percentages and money always in digits.
❌ "Save 3 months of expenses."
Source: your answer (Q3.4); measured 3/3; observed break.

**L4 (Must)** Dates written 5 November 2026.
Pass if: day, month in full, year; no "November 5th" or "05/11".
Source: your answer (Q3.4).

**L5 (Must)** No em dashes.
Pass if: zero "—" characters. Use a full stop or a comma.
Source: your answer (Q3.7); measured 0 in 3 samples; observed break.

**L6 (Must)** No exclamation marks.
Pass if: zero "!".
Source: your answer (Q3.7); measured 0 in 3 samples; observed break.

## 5. Facts, names and quotes

**F1 (Must)** Introduce the expert exactly: "Full Name, credential at Company, says:", then surname only.
Pass if: the intro line matches the pattern; later mentions use the surname ("Okafor says").
✅ "Mia Okafor, chartered financial planner at Ledgerwise, says:"
❌ "Finance expert Mia Okafor from Ledgerwise shares her top tips:"
Source: your answer (Q3.3); measured 3/3; observed break.

**F2 (Must)** Never invent facts, figures, quotes or credentials. No placeholders.
Pass if: every figure, claim and quote comes from the brief or source notes; nothing like "TBD", "XX%" or "[insert]"; anything missing is flagged for a person.
Source: Encoded default.

**F3 (Must)** Names and terms exactly as written below.
Pass if: character for character, including the ampersand and lower-case credentials.
Source: your answer (Q3.6).

**F4 (Should)** When a figure comes from a survey or study, name the source in the same sentence.
Pass if: every survey or study figure is followed by its source in that sentence.
✅ "...according to a Kettle & Crumb survey of 2,000 UK adults."
Source: measured in the one sample that cites a survey (S3). Please confirm.

**F5 (Must)** Quotes in double quotation marks.
Pass if: every quote uses " and "; no single quotation marks around quoted speech.
Source: your answer (Q3.3); measured 3/3.

**Always written exactly like this:**
- Ledgerwise
- Stridewell
- Kettle & Crumb
- Mia Okafor, chartered financial planner
- Daniel Reyes, chartered physiotherapist
- Hannah Price, head baker

## 6. Never use

**N1 (Must)** None of the words or phrases below, in any format.
Pass if: none appear anywhere, including in headlines and quotes.
Source: your answer (Q3.5, Q4.3: Ledgerwise "never say 'disaster'"); observed break; Encoded default (AI filler).

| Don't write | Write instead |
| --- | --- |
| thrilled, delighted to announce | (cut it, or say what happened) |
| game-changer | (say what changed) |
| in today's fast-paced world, in an ever-evolving landscape, it's no secret | (cut it and open on the point) |
| when it comes to, let's dive in, delve | (cut it and say the thing) |
| navigate | handle, deal with, plan for |
| unlock, elevate | get, save, find, improve |
| journey | (cut it) |
| disaster | (describe the actual cost, calmly) |
| Tip: | Why it matters: / What to do: |

Not banned, on purpose: "quietly" and "quiet". Many AI checkers flag them, but your own published work uses them well, so your kit allows them.

## Changelog

- **0.9 (5 November 2026)**: First kit. 32 rules (23 Must, 9 Should) from 3 published samples, your answers and one flagged AI draft.
