# Kit test report

Fernhill PR · kit 0.9 · 5 November 2026 · Example kit (Fernhill PR is fictional)

We wrote a test piece with your kit, then ran your checker on it and on the AI draft you sent us, so you can see both sides working before you use them.

## Test 1: writing a new piece

### The test brief (written by Encoded)

> Journalist request, UK national money pages: "Looking for a financial planner to share 5 money mistakes people make in their first year of self-employment."
> Expert: Mia Okafor, chartered financial planner at Ledgerwise.
> Mia's notes: "Self-employed people have no one setting aside tax, pension or savings for them. The full invoice lands in your account, so it feels like income: put 25 to 30% of every payment aside for tax. Open a separate business account before the first invoice; mixing accounts makes the tax return slower and expenses easy to miss. Payments on account catch people out in year two: the first bill can be 150% of what they expected. With no employer paying in, people go years without a pension; keep one going, even £50 a month. Income rarely arrives evenly, so aim for three months of essential costs." Quote: "The first year is about habits. Get the boring accounts set up early and everything after gets easier."

### The plan the writer made

- Format and outlet: expert comment listicle, UK national money pages (UK spelling, pounds)
- Headline promise: 5 · mistakes · practical and calm, not scary
- Brief points: 1 tax money, 2 separate account, 3 payments on account, 4 pension, 5 safety net
- Expert line: Mia Okafor, chartered financial planner at Ledgerwise, says:
- Closing quote: Mia's quote from the notes, split into two parts

### The draft

```
5 money mistakes new freelancers make, according to a chartered financial planner

Going self-employed means no one sets aside your tax, pension or savings for you. Payments on account then catch people out in year two.

Mia Okafor, chartered financial planner at Ledgerwise, says:

1. Spending the tax money
Why it matters: The full invoice lands in your account, so it feels like income.
What to do: Move 25 to 30% of every payment into a separate savings account the day it arrives.

2. Using one bank account for everything
Why it matters: Mixing personal and business spending makes your tax return slower and your expenses easy to miss.
What to do: Open a separate business account before you send your first invoice.

3. Forgetting payments on account
Why it matters: Payments on account start in your second year, and the first bill can be 150% of what you expected.
What to do: Ask your accountant to estimate that bill early and save towards it monthly.

4. Stopping pension payments
Why it matters: With no employer paying in, it is easy to go years without saving for retirement.
What to do: Set up a personal pension and keep it going, even at £50 a month.

5. Running without a safety net
Why it matters: Freelance income rarely arrives evenly, and one slow month can leave you short on bills.
What to do: Save three months of essential costs before you treat anything as spare.

"The first year is about habits," Okafor says. "Get the boring accounts set up early and everything after gets easier."
```

### The checker's verdict: READY

| Rule | Result | Note |
| --- | --- | --- |
| V1 Open on the point | Pass | First sentence states the problem: no one sets aside tax, pension or savings |
| S1 Shape | Pass | All five parts, in order |
| S2 Count | Pass | Headline 5, items 5 |
| S3 Labels | Pass | 5/5 items have both labels, exact |
| S4 No other labels | Pass | None |
| S5 Items match the noun | Pass | All five are mistakes |
| S8 Two-part closing quote | Pass | "...habits," Okafor says. "..." |
| S10 Brief coverage | Pass | See below |
| S11 Angle | Pass | Cautionary throughout; every item names a mistake and its cost |
| H1 Digit first | Pass | "5" |
| H2 Credential, never "expert" | Pass | "according to a chartered financial planner" |
| H3 Sentence case | Pass | |
| L1 UK spelling | Pass | No US spellings found |
| L2 Pounds | Pass | "£50 a month" |
| L3 Numbers | Pass | "three months"; "25 to 30%", "150%" |
| L4 Dates | Pass | No dates used |
| L5 No em dashes | Pass | 0 |
| L6 No exclamation marks | Pass | 0 |
| F1 Expert intro | Pass | Exact pattern; surname after |
| F2 Nothing invented | Pass | Every claim and figure is in Mia's notes |
| F3 Names exact | Pass | Ledgerwise; Mia Okafor, chartered financial planner |
| F5 Double quotation marks | Pass | |
| N1 Banned words | Pass | None found |

Should rules: all pass. 259 words, headline included, item numbers not counted (S9: 225 to 262). Headline 12 words (H4). Item subheads 3 to 6 words (S6). No contractions outside quotes (V4).

**Brief coverage:** 1 tax money → item 1 · 2 separate account → item 2 · 3 payments on account → item 3 · 4 pension → item 4 · 5 three months of costs → item 5. Nothing missing.

## Test 2: checking the AI draft you sent us

Your draft "6 Financial Mistakes Every New Parent Makes", run through `03-checker-prompt.md` (no brief supplied, so brief coverage is not checked):

### The checker's verdict: REWRITE

The count and the structure are wrong at the root, so line edits will not save it.

| Rule | What is wrong | Fix |
| --- | --- | --- |
| S2 Count | Headline says 6; the body has 7 items | Decide on 5 or 6 and merge items to match |
| S1 Shape | Standfirst does not open on the point; expert intro in the wrong pattern; no closing quote | Rebuild in the house shape |
| S3 Labels | No item has "Why it matters:" or "What to do:" | Add both labels to every item |
| S4 Other labels | "Tip:" used 7 times | Remove; use the two house labels |
| H2 Credential | "6 Financial Mistakes Every New Parent Makes" names no credential | "6 money mistakes new parents make, according to a chartered financial planner" |
| H3 Sentence case | Every word capitalised | Sentence case, as in the H2 fix |
| V1 Open on the point | "In today's fast-paced world, becoming a parent is a thrilling journey" | Open on the problem: what new parents miss |
| N1 Banned words | "in today's fast-paced world", "journey", "disaster", "unlock" | Cut each; say the plain thing |
| L5 Em dash | "thrilling journey — but" | Full stop |
| L6 Exclamation mark | "if you're not prepared!" | Full stop, and lose the scare framing (V2) |
| F1 Expert intro | "Finance expert Mia Okafor from Ledgerwise shares her top tips:" | "Mia Okafor, chartered financial planner at Ledgerwise, says:" |
| L1 UK spelling | "color-coded" | "colour-coded" |
| L2 Pounds | "$1,200 a month" | Pounds, and only if the figure is in the brief |
| L3 Numbers | "Save 3 months of expenses" | "three months" |
| F2 Unsourced figure | "$1,200 a month" has no source | Remove, or get the figure from the client |

15 Must breaks found. Every problem you listed in your note is caught, plus the unsourced childcare figure, which the note did not mention.

## Test 3: the automatic rule check

Your Claude skill includes a small script that checks 16 of your rules exactly, every time: item count, both labels, no extra labels, length, headline digit and case, UK spelling, pounds, number style, em dashes, exclamation marks, placeholders, exact names, double quotation marks and banned words.

| Run on | Result |
| --- | --- |
| Your 3 published pieces | PASS on all 3 (no false alarms on your real work) |
| The test draft above | PASS · 0 breaks · 259 words · 5 items |
| Your old AI draft | 14 Must breaks found automatically |
| Planted-error test | We planted one break for each of the 15 rules the script covers, one at a time, in the passing test draft. **Caught 15 of 15**, each under the right rule. The only extra flag was length, where the planted text really did push the draft over 262 words. |

The AI still judges what a script cannot: voice, angle, brief coverage and whether every fact came from the brief.

## What this shows

Your kit now catches your three most common fixes (wrong item count, US spelling and dollars, "expert" and made-up labels) before a draft reaches an editor. The writer produced a piece that passed every rule on the first try, using only facts from the brief.
