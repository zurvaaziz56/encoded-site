# Setting up your Fernhill PR kit

Version 0.9 · 5 November 2026

About 10 minutes. You do this once per person, or once for the team in tools with shared workspaces.

## Try it in 2 minutes

Before anything else, see it work:

1. Open `03-checker-prompt.md` and copy everything below the line into any AI chat.
2. Paste this into the draft slot:

   > 4 Money Mistakes New Parents Make, According To An Expert
   >
   > Finance expert Mia Okafor from Ledgerwise says:
   >
   > 1. Not saving. Tip: save 3 months of costs in a color-coded budget.

3. You should get REWRITE, with at least these breaks found: S2 (headline says 4, one item), H2 ("expert"), H3 (Title Case), S3 and S4 (labels), L1 (color), L3 (3 months), F1 (expert intro).

## What's in your kit

| File | What it is | Who uses it |
| --- | --- | --- |
| `01-house-rules.md` | Your rules, written down | Everyone. Share it with new starters and freelancers. |
| `02-writer-skill.zip` | Your house style as a Claude skill | Claude users |
| `03-checker-prompt.md` | Paste-in checker for any draft, from any tool | Editors |
| `04-chatgpt-instructions.md` | Your rules set up for ChatGPT | ChatGPT users |
| `06-kit-test-report.md` | Your kit writing a piece, and catching the problems in the AI draft you sent us | Read once |

## Claude

1. You need a paid Claude plan (Pro, Max, Team or Enterprise). Open Claude, go to Settings, then Capabilities, and make sure code execution and Skills are switched on.
2. In the Skills section, choose Upload skill and pick `02-writer-skill.zip`.
3. In any chat, ask for a draft as usual: "Draft an expert comment piece for Ledgerwise on..." Claude follows your house style automatically.
4. To check a draft from anywhere, say "check this against Fernhill house style" and paste it.
5. On a Team plan, an owner can add the skill for everyone.

## ChatGPT

1. Go to Explore GPTs, then Create, then Configure.
2. Name it "Fernhill house style". Paste the box from `04-chatgpt-instructions.md` into Instructions.
3. Under Knowledge, upload `01-house-rules.md`.
4. Save it for your workspace so the team can use it. Or paste the same text into a Project's Instructions instead.

## The checker (works anywhere)

1. Open `03-checker-prompt.md` and copy everything below the line.
2. Paste it into a new chat in any AI tool, then paste your draft and its brief underneath.
3. You get a verdict (Ready, Fix first or Rewrite), every break with its exact fix, and a corrected draft when the fixes are simple.

## Getting the most out of it

- Always give the AI the journalist's request, the outlet and the expert's notes. Most bad drafts come from missing inputs.
- If the checker finds the same break twice in a week, tell us. That rule needs tightening.
- Your rules will change. Tell us what changed and we will update every file in your kit. The Calibrated Kit goes further: we tune the rules to the edits your team actually makes.

Questions: reply to the email this kit came with.
