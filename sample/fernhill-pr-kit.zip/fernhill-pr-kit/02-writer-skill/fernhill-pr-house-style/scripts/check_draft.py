#!/usr/bin/env python3
"""Encoded mechanical draft checker.

Checks the rules a script can verify exactly (counts, labels, banned phrases,
punctuation, spelling variant, length, placeholders, headline case), so the AI
only has to judge the rules that need judgment (voice, angle, brief coverage).

Usage:
    python check_draft.py DRAFT.txt [--rules mechanical-rules.json] [--format listicle|press_release|pitch|byline] [--json]
    python check_draft.py SAMPLE.txt --count     (word count only, for measuring samples in Stage 2)

The rules file sits next to this script by default (../references/mechanical-rules.json
inside a writer skill). Exit code 0 = no Must breaks, 1 = Must breaks found.
Standard library only.
"""
import argparse
import json
import os
import re
import sys

WORD_NUMS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7,
             "eight": 8, "nine": 9, "ten": 10, "eleven": 11, "twelve": 12}
SMALL_WORDS = {"a", "an", "and", "as", "at", "but", "by", "for", "from", "in", "into", "of",
               "on", "or", "the", "to", "with", "vs"}


def load_rules(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def word_count(text):
    """A word is a whitespace token containing a letter or digit. Headline included;
    list numbers at the start of a line ("1.", "2)") and pure punctuation (an em dash) are not counted."""
    body = re.sub(r"^\s*\d+[.)]\s", "", text, flags=re.M)
    return len([w for w in body.split() if re.search(r"[A-Za-z0-9]", w)])


def headline_of(text):
    for line in text.splitlines():
        if line.strip():
            return line.strip()
    return ""


def numbered_items(text):
    return re.findall(r"^\s*(\d+)[.)]\s+(.+)$", text, flags=re.M)


def item_blocks(text):
    """Split the body into numbered item blocks (item line plus following lines)."""
    lines = text.splitlines()
    blocks, cur = [], None
    for line in lines:
        if re.match(r"^\s*\d+[.)]\s+", line):
            if cur is not None:
                blocks.append(cur)
            cur = [line]
        elif cur is not None:
            if line.strip().startswith('"'):
                # a closing quote ends the last item
                blocks.append(cur)
                cur = None
                continue
            cur.append(line)
    if cur is not None:
        blocks.append(cur)
    return ["\n".join(b) for b in blocks]


def is_title_case(headline):
    words = re.findall(r"[A-Za-z][A-Za-z'\-]*", headline)
    if len(words) < 4:
        return False
    later = [w for w in words[1:] if w.lower() not in SMALL_WORDS]
    if not later:
        return False
    caps = [w for w in later if w[0].isupper()]
    return len(caps) / len(later) > 0.6


def check(text, rules, fmt):
    breaks = []

    def add(rule_id, severity, problem, fix):
        breaks.append({"rule": rule_id, "severity": severity, "problem": problem, "fix": fix})

    def applies(r):
        scope = r.get("formats")
        return not scope or fmt in scope

    head = headline_of(text)
    low = text.lower()

    for r in rules.get("rules", []):
        if not applies(r):
            continue
        rid, sev, kind = r["id"], r.get("severity", "Must"), r["type"]

        if kind == "count_matches_headline":
            m = re.match(r"^\s*(\d+|" + "|".join(WORD_NUMS) + r")\b", head, flags=re.I)
            items = numbered_items(text)
            if m:
                promised = int(m.group(1)) if m.group(1).isdigit() else WORD_NUMS[m.group(1).lower()]
                if promised != len(items):
                    add(rid, sev, f"Headline promises {promised}, body has {len(items)} numbered items",
                        "Merge or split items so the count matches the headline")

        elif kind == "headline_starts_with_digit":
            if not re.match(r"^\s*\d", head):
                add(rid, sev, f'Headline does not start with a digit: "{head[:60]}"', "Start with the number, as a digit")

        elif kind == "headline_sentence_case":
            if is_title_case(head):
                add(rid, sev, f'Headline looks like Title Case: "{head[:60]}"', "Use sentence case")

        elif kind == "headline_title_case":
            if not is_title_case(head):
                add(rid, sev, f'Headline is not in Title Case: "{head[:60]}"', "Capitalise main words (small words lower case)")

        elif kind in ("required_pattern", "forbidden_pattern"):
            where = r.get("scope", "all")
            target = {"headline": head,
                      "first_lines": "\n".join([l for l in text.splitlines() if l.strip()][:3]),
                      "last_lines": "\n".join([l for l in text.splitlines() if l.strip()][-4:]),
                      "body": "\n".join(text.splitlines()[1:])}.get(where, text)
            found = re.search(r["pattern"], target, flags=re.M | (re.I if r.get("ignore_case") else 0))
            if kind == "required_pattern" and not found:
                add(rid, sev, r.get("problem", f"Required pattern not found in {where}"), r.get("fix", "Add it in the house format"))
            if kind == "forbidden_pattern" and found:
                add(rid, sev, r.get("problem", f'Found "{found.group(0)[:40]}" in {where}'), r.get("fix", "Remove or rewrite it"))

        elif kind == "headline_must_not_contain":
            for term in r.get("terms", []):
                if term.lower() in head.lower():
                    add(rid, sev, f'Headline contains "{term}"', r.get("fix", "Use the expert's real credential"))

        elif kind == "required_labels_per_item":
            labels = r["labels"]
            missing = {lab: [] for lab in labels}
            wrong_order = []
            for i, block in enumerate(item_blocks(text), 1):
                pos = [block.find(lab) for lab in labels]
                for lab, p in zip(labels, pos):
                    if p < 0:
                        missing[lab].append(str(i))
                if all(p >= 0 for p in pos) and pos != sorted(pos):
                    wrong_order.append(str(i))
            for lab, items in missing.items():
                if items:
                    add(rid, sev, f'Label "{lab}" missing in item(s) {", ".join(items)}', f'Add "{lab}" exactly as written')
            if wrong_order:
                add(rid, sev, f"Labels in the wrong order in item(s) {', '.join(wrong_order)}", " then ".join(labels))

        elif kind == "forbidden_labels":
            for lab in r.get("labels", []):
                n = text.count(lab)
                if n:
                    add(rid, sev, f'"{lab}" used {n} time(s)', "Remove it; use the house labels only")

        elif kind == "banned_phrases":
            for ph in r.get("phrases", []):
                # "*" matches up to three extra words, e.g. "in today's * world"
                pat = re.escape(ph.lower()).replace(r"\*", r"(?:\S+\s+){0,3}?\S*")
                n = len(re.findall(r"(?<![A-Za-z])" + pat + r"(?![A-Za-z])", low))
                if n:
                    add(rid, sev, f'Banned phrase "{ph}" used {n} time(s)', r.get("fix", "Cut it and say the plain thing"))

        elif kind == "forbidden_chars":
            scan = text
            if r.get("except_pattern"):
                scan = re.sub(r["except_pattern"], "", text, flags=re.M)
            for ch in r.get("chars", []):
                n = scan.count(ch)
                if n:
                    add(rid, sev, f'"{ch}" used {n} time(s)', r.get("fix", "Remove it"))

        elif kind == "spelling_variant":
            for wrong, right in r.get("pairs", {}).items():
                n = len(re.findall(r"(?<![A-Za-z])" + re.escape(wrong) + r"(?![a-z])", text, flags=re.I))
                if n:
                    add(rid, sev, f'"{wrong}" used {n} time(s)', f'Use "{right}"')

        elif kind == "forbidden_currency":
            for sym in r.get("symbols", []):
                if sym in text:
                    add(rid, sev, f'Currency "{sym}" used', r.get("fix", "Use the house currency"))

        elif kind == "word_count_range":
            wc = word_count(text)
            lo, hi = r["min"], r["max"]
            if wc < lo or wc > hi:
                add(rid, sev, f"{wc} words (target {lo} to {hi}, headline included, item numbers not counted)",
                    "Trim or expand to the measured range")

        elif kind == "placeholders":
            pats = r.get("patterns", [r"\bTBD\b", r"\bTBC\b", r"\bXX+%?", r"\[insert[^\]]*\]", r"\[[A-Z ]{3,}\]", r"lorem ipsum"])
            for p in pats:
                for m in re.finditer(p, text, flags=re.I):
                    add(rid, sev, f'Placeholder "{m.group(0)}"', "Replace with the real detail or flag it for a person")

        elif kind == "small_numbers_in_words":
            body = "\n".join(text.splitlines()[1:])
            body = re.sub(r"^\s*\d+[.)]\s+", "", body, flags=re.M)
            for m in re.finditer(r"(?<![\d£$€.,:/-])\b([1-9])\b(?![\d%,.:/]|\s*(?:%|per cent|percent|m\b|bn\b|k\b|am\b|pm\b))", body):
                add(rid, sev, f'"{m.group(1)}" written as a digit', "Write one to nine in words")

        elif kind == "double_quotes_only":
            for m in re.finditer(r"(?:^|\s)'([^'\n]{12,}?)'(?=[\s.,;:]|$)", text):
                add(rid, sev, f"Single quotation marks around: '{m.group(1)[:40]}'", "Use double quotation marks")

        elif kind == "exact_terms":
            for term in r.get("terms", []):
                core = re.sub(r"[^A-Za-z0-9 ]", "", term).lower()
                for m in re.finditer(re.escape(core.split()[0]), low):
                    window = text[m.start(): m.start() + len(term) + 4]
                    norm = re.sub(r"[^A-Za-z0-9 ]", "", window).lower()
                    if norm.startswith(core) and not window.startswith(term):
                        add(rid, sev, f'"{window[:len(term)]}" should be written "{term}"', "Copy the name exactly")
                        break

    must = [b for b in breaks if b["severity"] == "Must"]
    return {
        "verdict": "PASS" if not must else "BREAKS FOUND",
        "must_breaks": len(must),
        "should_breaks": len(breaks) - len(must),
        "word_count": word_count(text),
        "items": len(numbered_items(text)),
        "breaks": breaks,
        "note": "Mechanical rules only. Voice, angle, brief coverage and facts still need the AI check.",
    }


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    default_rules = os.path.join(here, "..", "references", "mechanical-rules.json")
    ap = argparse.ArgumentParser(description="Check a draft against mechanical house rules.")
    ap.add_argument("draft")
    ap.add_argument("--rules", default=default_rules)
    ap.add_argument("--format", default=None, help="the format values used in the rules file, e.g. listicle, press_release, pitch, byline (default: default_format)")
    ap.add_argument("--count", action="store_true", help="print the word count only")
    ap.add_argument("--json", action="store_true", help="print JSON instead of a table")
    a = ap.parse_args()

    if a.count:
        with open(a.draft, encoding="utf-8") as f:
            print(word_count(f.read()))
        sys.exit(0)
    rules = load_rules(a.rules)
    fmt = a.format or rules.get("default_format", "listicle")
    with open(a.draft, encoding="utf-8") as f:
        text = f.read()
    res = check(text, rules, fmt)

    if a.json:
        print(json.dumps(res, indent=2, ensure_ascii=False))
    else:
        print(f"{res['verdict']} · {res['must_breaks']} Must, {res['should_breaks']} Should · "
              f"{res['word_count']} words · {res['items']} items · format: {fmt}")
        for b in res["breaks"]:
            print(f"- {b['rule']} ({b['severity']}): {b['problem']}. Fix: {b['fix']}")
        print(res["note"])
    sys.exit(0 if res["must_breaks"] == 0 else 1)


if __name__ == "__main__":
    main()
